<?php

namespace Livewire;

use Livewire\Features\SupportFileUploads\WithFileUploads as BaseWithFileUploads;

trait WithFileUploads
{
   use BaseWithFileUploads;
}
